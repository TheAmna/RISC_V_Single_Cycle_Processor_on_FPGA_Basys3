`timescale 1ns / 1ps

module RegisterFile (
    input  wire        clk,
    input  wire        clk_en,
    input  wire        rst,
    input  wire        WriteEnable,
    input  wire [4:0]  rs1,
    input  wire [4:0]  rs2,
    input  wire [4:0]  rd,
    input  wire [31:0] WriteData,
    output wire [31:0] ReadData1,   // asynchronous read port 1
    output wire [31:0] ReadData2    // asynchronous read port 2
);
    reg [31:0] regs [0:31];
    integer i;
    initial begin
        for (i = 0; i < 32; i = i + 1)
            regs[i] = 32'b0;
    end

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            for (i = 0; i < 32; i = i + 1)
                regs[i] <= 32'b0;
        end
        else if (clk_en) begin
            if (WriteEnable == 1'b1) begin
                if (rd != 5'b00000) begin
                    regs[rd] <= WriteData;
                end
            end
        end
    end

    assign ReadData1 = (rs1 == 5'b00000) ? 32'b0 : regs[rs1];
    assign ReadData2 = (rs2 == 5'b00000) ? 32'b0 : regs[rs2];
endmodule