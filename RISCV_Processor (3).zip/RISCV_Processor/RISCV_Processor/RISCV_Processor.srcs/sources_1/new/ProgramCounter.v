`timescale 1ns / 1ps

module ProgramCounter (
    input  wire        clk,
    input  wire        clk_en,
    input  wire        rst,
    input  wire [31:0] PC_Next, // next address (from mux2)
    output reg  [31:0] PC   // current address (to instruction memory)
);
    always @(posedge clk or posedge rst) begin
        if (rst)
            PC <= 32'h00000000; // reset  start from address 0
        else if (clk_en)
            PC <= PC_Next; // update to next address every cycle
    end
endmodule