`timescale 1ns / 1ps

module immGen (
    input  wire [31:0] instruction, // 32-bit instruction
    output reg  [31:0] imm_out      // sign-extended immediate
);

    wire [6:0] opcode = instruction[6:0];
    localparam LOAD    = 7'b0000011; // I-type
    localparam I_ARITH = 7'b0010011; // I-type
    localparam JALR    = 7'b1100111; // I-type
    localparam STORE   = 7'b0100011; // S-type
    localparam BRANCH  = 7'b1100011; // B-type
    localparam JAL     = 7'b1101111; // J-type  ? NEW

    always @(*) begin
        case (opcode)
            // I-type
            LOAD, I_ARITH, JALR: begin
                imm_out = {{20{instruction[31]}}, instruction[31:20]};
            end
            // S-type
            STORE: begin
                imm_out = {{20{instruction[31]}},
                           instruction[31:25],
                           instruction[11:7]};
            end
            // B-type
            BRANCH: begin
                imm_out = {{19{instruction[31]}},
                           instruction[31],
                           instruction[7],
                           instruction[30:25],
                           instruction[11:8],
                           1'b0};
            end
            // J-type  ? NEW
            JAL: begin
                imm_out = {{11{instruction[31]}},
                           instruction[31],
                           instruction[19:12],
                           instruction[20],
                           instruction[30:21],
                           1'b0};
            end
            default: begin
                imm_out = 32'd0;
            end
        endcase
    end
endmodule