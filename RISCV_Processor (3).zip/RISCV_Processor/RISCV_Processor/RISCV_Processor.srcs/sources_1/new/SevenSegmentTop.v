`timescale 1ns / 1ps
// ============================================================
// SevenSegmentTop.v
// Top-level wrapper for the four-digit seven segment display
//
// Instantiates:
//   SevenSegmentCtrl  - selects which digit and nibble is active
//   SevenSegment      - decodes nibble to segment pattern
//
// The inversion (assign led_segment = ~segments) converts the
// internal active-HIGH encoding to active-LOW for Basys3 pins.
//
// Inputs:
//   clk              - 100 MHz fast clock (NOT slow CPU clock)
//   write_en         - latch new value (tied to LEDWrite signal)
//   data_in          - 16-bit value to display (from mem_write_data)
//
// Outputs:
//   led_segment [6:0] - segment cathodes to Basys3 pins (active LOW)
//   anode_activate[3:0] - digit anodes to Basys3 pins (active LOW)
//   dp               - decimal point, always OFF (tied high)
// ============================================================

module SevenSegmentTop (
    input  wire        clk,              // 100 MHz fast clock
    input  wire        rst,
    input  wire        write_en,         // from LEDWrite in ProcessorFPGA
    input  wire [15:0] data_in,          // mem_write_data[31:16]
    output wire [6:0]  led_segment,      // to Basys3 seg pins
    output wire [3:0]  anode_activate,   // to Basys3 an pins
    output wire        dp                // decimal point
);

    // decimal point always off (active low, so drive high)
    assign dp = 1'b1;

    // ----------------------------------------------------------------
    // Latch the display value when CPU writes to LED address
    // Holds the last written value stable between CPU writes
    // ----------------------------------------------------------------
    reg [15:0] display_reg;

    always @(posedge clk) begin
        if (rst) begin
            display_reg <= 16'd0;
        end
        else if (write_en) begin
            display_reg <= data_in;
        end
    end

    // ----------------------------------------------------------------
    // Multiplexer - cycles through 4 digits
    // ----------------------------------------------------------------
    wire [3:0] led_binary;

    SevenSegmentCtrl u_ctrl (
        .clk              (clk),
        .displayed_number (display_reg),
        .anode_activate   (anode_activate),
        .led_binary       (led_binary)
    );

    // ----------------------------------------------------------------
    // Decoder - nibble to segment pattern
    // ----------------------------------------------------------------
    wire [6:0] segments_high;  // active HIGH from decoder

    SevenSegment u_decoder (
        .binary   (led_binary),
        .segments (segments_high)
    );

    // Basys3 segments are active LOW, so invert decoder output
    assign led_segment = ~segments_high;

endmodule