`timescale 1ns / 1ps
// ============================================================
// ProcessorFPGA.v  -  FPGA Top-Level Wrapper
// Board: Digilent Basys3 (Artix-7, 100 MHz onboard clock)
//
// Memory Map (Lab 8 AddressDecoder):
//   0x000 - 0x1FF  -> Data Memory   (address[9] = 0)
//   0x200 - 0x2FF  -> LEDs          (address[9:8] = 10)
//   0x300 - 0x3FF  -> Switches      (address[9:8] = 11)
//
// Clock strategy (clk_en pattern):
//   ALL modules run on fast 100MHz clk through proper clock network
//   clk_en is a single pulse every 250ms (one instruction per pulse)
//   Writes to registers, memory, LEDs are GATED with clk_en
//   This prevents timing issues caused by using slow_clk as actual clock
//
// Display:
//   mem_write_data[15:0] -> LEDs        (binary countdown)
//   mem_write_data[15:0] -> Seven Seg   (hex countdown)
//   Both triggered by LEDWrite & clk_en
// ============================================================

module ProcessorFPGA #(
    parameter CLK_DIVIDER = 25_000_000  // 4 instructions/sec at 100MHz
)(
    input  wire        clk,       // 100 MHz Basys3 onboard clock (W5)
    input  wire        rst_raw,   // BTNC reset button (raw, needs debounce)
    input  wire [15:0] sw,        // SW0-SW15 physical switches
    output wire [15:0] led,       // LD0-LD15 physical LEDs
    output wire [6:0]  seg,       // seven segment cathodes (active low)
    output wire [3:0]  an,        // seven segment anodes   (active low)
    output wire        dp         // decimal point          (active low)
);

    // ----------------------------------------------------------------
    // Debounce reset button
    // BTNC on Basys3 bounces on press/release
    // debouncer holds output stable for 500_000 cycles (~5ms at 100MHz)
    // ----------------------------------------------------------------
    wire rst_clean;

    debouncer u_debounce (
        .clk   (clk),
        .pbin  (rst_raw),
        .pbout (rst_clean)
    );

    // ----------------------------------------------------------------
    // Clock enable pulse
    // clock_divider produces a single 10ns HIGH pulse every 250ms
    // This pulse is used as clk_en - NOT as an actual clock
    // All modules receive the real 100MHz clk for their clock input
    // ----------------------------------------------------------------
    wire clk_en;

    clock_divider #(
        .MAX_COUNT (CLK_DIVIDER)
    ) u_clk_div (
        .clk      (clk),
        .rst      (rst_clean),
        .slow_clk (clk_en)
    );

    // ----------------------------------------------------------------
    // Memory bus wires
    // CPU drives these, AddressDecoder routes them to correct device
    // ----------------------------------------------------------------
    wire [31:0] mem_address;
    wire [31:0] mem_write_data;
    wire        mem_write_en;
    wire        mem_read_en;
    wire [31:0] mem_read_data;

    // ----------------------------------------------------------------
    // CPU
    // Runs on 100MHz clk, advances only when clk_en is high
    // clk_en is passed into ProgramCounter and RegisterFile
    // so PC and registers only update on the enabled cycle
    // ----------------------------------------------------------------
    TopLevelProcessor u_processor (
        .clk            (clk),
        .clk_en         (clk_en),
        .rst            (rst_clean),
        .mem_address    (mem_address),
        .mem_write_data (mem_write_data),
        .mem_write_en   (mem_write_en),
        .mem_read_en    (mem_read_en),
        .mem_read_data  (mem_read_data)
    );

    // ----------------------------------------------------------------
    // Address Decoder
    // Looks at mem_address bits[9:8] and decides which device responds
    //   0x000-0x1FF -> DataMemory
    //   0x200-0x2FF -> LEDs
    //   0x300-0x3FF -> Switches
    // ----------------------------------------------------------------
    wire DataMemWrite;
    wire DataMemRead;
    wire LEDWrite;
    wire SwitchReadEnable;

    AddressDecoder u_addr_dec (
        .readEnable       (mem_read_en),
        .writeEnable      (mem_write_en),
        .address          (mem_address),
        .DataMemWrite     (DataMemWrite),
        .DataMemRead      (DataMemRead),
        .LEDWrite         (LEDWrite),
        .SwitchReadEnable (SwitchReadEnable)
    );

    // ----------------------------------------------------------------
    // Data Memory (0x000 - 0x1FF)
    // Runs on 100MHz clk
    // Write is gated: DataMemWrite & clk_en
    // Without clk_en gate, the synchronous write would fire every
    // 100MHz cycle while DataMemWrite is high = thousands of writes
    // per instruction instead of exactly one
    // ----------------------------------------------------------------
    wire [31:0] dmem_read_data;

    DataMemory u_datamem (
        .clk        (clk),
        .MemWrite   (DataMemWrite & clk_en),
        .MemRead    (DataMemRead),
        .address    (mem_address),
        .write_data (mem_write_data),
        .read_data  (dmem_read_data)
    );

    // ----------------------------------------------------------------
    // LED Peripheral (0x200 - 0x2FF)
    // Runs on 100MHz clk
    // Write gated with clk_en - LED register latches exactly once
    // per SW instruction, not thousands of times
    // Shows mem_write_data[15:0] on LD0-LD15
    // ----------------------------------------------------------------
    wire [31:0] led_read_data;   // always 0 - LEDs are write only

    leds u_leds (
        .clk         (clk),
        .rst         (rst_clean),
        .writeData   (mem_write_data),
        .writeEnable (LEDWrite & clk_en),
        .readEnable  (1'b0),
        .memAddress  (mem_address[31:2]),
        .readData    (led_read_data),
        .leds        (led)
    );

    // ----------------------------------------------------------------
    // Switch Peripheral (0x300 - 0x3FF)
    // Runs on 100MHz clk
    // Two-stage synchroniser inside switches.v removes metastability
    // readEnable is combinational - no need to gate with clk_en
    // ----------------------------------------------------------------
    wire [31:0] sw_read_data;

    switches u_switches (
        .clk         (clk),
        .rst         (rst_clean),
        .btns        (16'd0),
        .writeData   (32'd0),
        .writeEnable (1'b0),
        .readEnable  (SwitchReadEnable),
        .memAddress  (mem_address[31:2]),
        .switches    (sw),
        .readData    (sw_read_data)
    );

    // ----------------------------------------------------------------
    // Read Data Mux
    // Returns correct peripheral data back to CPU on LW instruction
    // SwitchReadEnable and DataMemRead are mutually exclusive
    // (AddressDecoder guarantees only one is active at a time)
    // ----------------------------------------------------------------
    reg [31:0] mem_read_data_reg;

    always @(*) begin
        if (SwitchReadEnable) begin
            mem_read_data_reg = sw_read_data;
        end
        else begin
            mem_read_data_reg = dmem_read_data;
        end
    end

    assign mem_read_data = mem_read_data_reg;

    // ----------------------------------------------------------------
    // Seven Segment Display
    // Shows mem_write_data[15:0] in hex on 4-digit display
    // Same data as LEDs but in hexadecimal format
    // Triggered by same LEDWrite & clk_en as LEDs
    // One SW instruction to 0x200 updates both LEDs and seven seg
    // Runs on fast 100MHz clk for flicker-free digit multiplexing
    // ----------------------------------------------------------------
    SevenSegmentTop u_sevenseg (
        .clk            (clk),
        .rst            (rst_clean),
        .write_en       (LEDWrite & clk_en),
        .data_in        (mem_write_data[15:0]),
        .led_segment    (seg),
        .anode_activate (an),
        .dp             (dp)
    );

endmodule