`timescale 1ns / 1ps
// ============================================================
// SevenSegment.v
// Hex to seven segment decoder
// Input:  4-bit nibble (0-F)
// Output: 7-bit segment pattern, active HIGH internally
//         (SevenSegmentTop inverts before sending to Basys3 pins)
//
// Segment layout on Basys3:
//      a
//     ---
//  f |   | b
//     ---    <- g
//  e |   | c
//     ---
//      d
//
// Bit order: segments = {a, b, c, d, e, f, g}
// ============================================================

module SevenSegment (
    input  wire [3:0] binary,
    output reg  [6:0] segments   // {a,b,c,d,e,f,g} active HIGH
);
    always @(*) begin
        if (binary == 4'd0) begin
            segments = 7'b1111110;  // 0: a,b,c,d,e,f on, g off
        end
        else if (binary == 4'd1) begin
            segments = 7'b0110000;  // 1: b,c on
        end
        else if (binary == 4'd2) begin
            segments = 7'b1101101;  // 2: a,b,d,e,g on
        end
        else if (binary == 4'd3) begin
            segments = 7'b1111001;  // 3: a,b,c,d,g on
        end
        else if (binary == 4'd4) begin
            segments = 7'b0110011;  // 4: b,c,f,g on
        end
        else if (binary == 4'd5) begin
            segments = 7'b1011011;  // 5: a,c,d,f,g on
        end
        else if (binary == 4'd6) begin
            segments = 7'b1011111;  // 6: a,c,d,e,f,g on
        end
        else if (binary == 4'd7) begin
            segments = 7'b1110000;  // 7: a,b,c on
        end
        else if (binary == 4'd8) begin
            segments = 7'b1111111;  // 8: all on
        end
        else if (binary == 4'd9) begin
            segments = 7'b1111011;  // 9: a,b,c,d,f,g on
        end
        else if (binary == 4'd10) begin
            segments = 7'b1110111;  // A: a,b,c,e,f,g on
        end
        else if (binary == 4'd11) begin
            segments = 7'b0011111;  // B: c,d,e,f,g on
        end
        else if (binary == 4'd12) begin
            segments = 7'b1001110;  // C: a,d,e,f on
        end
        else if (binary == 4'd13) begin
            segments = 7'b0111101;  // D: b,c,d,e,g on
        end
        else if (binary == 4'd14) begin
            segments = 7'b1001111;  // E: a,d,e,f,g on
        end
        else begin
            segments = 7'b1000111;  // F: a,e,f,g on
        end
    end
endmodule