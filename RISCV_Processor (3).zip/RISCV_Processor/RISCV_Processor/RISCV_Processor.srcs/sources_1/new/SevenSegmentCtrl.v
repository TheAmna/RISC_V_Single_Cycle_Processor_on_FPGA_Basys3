`timescale 1ns / 1ps
// ============================================================
// SevenSegmentCtrl.v
// Time-division multiplexer for 4-digit seven segment display
//
// Cycles through 4 digits rapidly so all appear lit to human eye
// Uses top 2 bits of a 20-bit counter running at 100MHz:
//   Full counter period = 2^20 cycles = ~10.5ms
//   Each digit active for 2^18 cycles = ~2.6ms  (~381Hz per digit)
//   381Hz is well above flicker threshold (~50Hz) so no flicker
//
// Outputs:
//   anode_activate: which digit is ON (active LOW on Basys3)
//                   4'b1110 = rightmost digit
//                   4'b0111 = leftmost digit
//   led_binary:     4-bit nibble for the active digit
//                   fed into SevenSegment decoder
// ============================================================

module SevenSegmentCtrl (
    input  wire        clk,               // 100 MHz fast clock
    input  wire [15:0] displayed_number,  // 16-bit value to show
    output reg  [3:0]  anode_activate,    // digit select (active low)
    output reg  [3:0]  led_binary         // nibble for active digit
);
    // 20-bit free-running counter, no reset needed
    // just rolls over naturally
    reg [19:0] refresh_counter;

    always @(posedge clk) begin
        refresh_counter <= refresh_counter + 20'd1;
    end

    // top 2 bits select which digit is active
    wire [1:0] digit_sel;
    assign digit_sel = refresh_counter[19:18];

    always @(*) begin
        if (digit_sel == 2'b00) begin
            anode_activate = 4'b0111;                    // leftmost digit
            led_binary     = displayed_number[15:12];    // highest nibble
        end
        else if (digit_sel == 2'b01) begin
            anode_activate = 4'b1011;                    // second digit
            led_binary     = displayed_number[11:8];
        end
        else if (digit_sel == 2'b10) begin
            anode_activate = 4'b1101;                    // third digit
            led_binary     = displayed_number[7:4];
        end
        else begin
            anode_activate = 4'b1110;                    // rightmost digit
            led_binary     = displayed_number[3:0];      // lowest nibble
        end
    end

endmodule