`timescale 1ns / 1ps
// ============================================================
// TopLevelProcessor.v  -  MODIFIED for Part B
// New instructions: JAL, JALR (BNE already worked via funct3)
//
// Key datapath changes:
//  1. MainControl now outputs Jump and JumpReg signals
//  2. PC-next mux extended to 3 inputs:
//       00 -> PC+4         (normal)
//       01 -> BranchTarget (branch taken OR JAL)
//       10 -> ALUResult    (JALR: rs1+imm)
//  3. Writeback mux extended to 3 inputs:
//       00 -> ALUResult    (R-type, I-arith)
//       01 -> MemReadData  (Load)
//       10 -> PC+4         (JAL, JALR: save return address)
//  4. Expose memory ports so ProcessorFPGA can attach
//     LED and switch peripherals
// ============================================================

module TopLevelProcessor (
    input  wire        clk,
    input  wire        clk_en,
    input  wire        rst,
    // Memory interface (for ProcessorFPGA peripheral mapping)
    output wire [31:0] mem_address,
    output wire [31:0] mem_write_data,
    output wire        mem_write_en,
    output wire        mem_read_en,
    input  wire [31:0] mem_read_data
);

    // --------------------------------------------------------
    // PC WIRES
    // --------------------------------------------------------
    wire [31:0] PC;
    wire [31:0] PC_Plus4;
    wire [31:0] BranchTarget;
    wire [31:0] PC_Next;
    wire        PCSrc;        // branch taken
    wire [31:0] ALUResult_PC; // JALR target (ALUResult & ~1)

    // --------------------------------------------------------
    // INSTRUCTION FIELDS
    // --------------------------------------------------------
    wire [31:0] instruction;
    wire [6:0]  opcode   = instruction[6:0];
    wire [4:0]  rd_addr  = instruction[11:7];
    wire [2:0]  funct3   = instruction[14:12];
    wire [4:0]  rs1_addr = instruction[19:15];
    wire [4:0]  rs2_addr = instruction[24:20];
    wire [6:0]  funct7   = instruction[31:25];

    // --------------------------------------------------------
    // CONTROL SIGNALS
    // --------------------------------------------------------
    wire        RegWrite, ALUSrc, MemRead, MemWrite, MemtoReg;
    wire        Branch, Jump, JumpReg;
    wire [1:0]  ALUOp;
    wire [3:0]  ALUControl;

    // --------------------------------------------------------
    // DATAPATH WIRES
    // --------------------------------------------------------
    wire [31:0] ReadData1, ReadData2, WriteData;
    wire [31:0] imm_out;
    wire [31:0] ALU_B;
    wire [31:0] ALUResult;
    wire        Zero, blt;
    wire [31:0] MemReadData;

    // --------------------------------------------------------
    // BRANCH CONDITION  (BEQ / BNE / BLT / BGE via funct3)
    // BNE = funct3 001 -> ~Zero  (already handled, no change)
    // --------------------------------------------------------
    reg branch_taken;
    always @(*) begin
        case (funct3)
            3'b000: branch_taken = Zero;    // BEQ
            3'b001: branch_taken = ~Zero;   // BNE  <-- Part B demo
            3'b100: branch_taken = blt;     // BLT
            3'b101: branch_taken = ~blt;    // BGE
            default: branch_taken = 1'b0;
        endcase
    end
    assign PCSrc = Branch & branch_taken;

    // --------------------------------------------------------
    // PC-NEXT SELECTION
    //   Jump    -> BranchTarget (PC + J-imm)
    //   PCSrc   -> BranchTarget (PC + B-imm)
    //   JumpReg -> ALUResult & ~1 (rs1 + imm, bit0 cleared)
    //   else    -> PC + 4
    // --------------------------------------------------------
    assign ALUResult_PC = {ALUResult[31:1], 1'b0};  // clear bit 0 per spec

    reg [31:0] PC_Next_reg;
    always @(*) begin
        if      (JumpReg)          PC_Next_reg = ALUResult_PC;   // JALR
        else if (Jump || PCSrc)    PC_Next_reg = BranchTarget;   // JAL / branch
        else                       PC_Next_reg = PC_Plus4;       // sequential
    end
    assign PC_Next = PC_Next_reg;

    // --------------------------------------------------------
    // WRITEBACK SELECTION
    //   MemtoReg=1             -> MemReadData (Load)
    //   Jump=1 or JumpReg=1   -> PC+4        (JAL/JALR save RA)
    //   else                   -> ALUResult   (R/I-arith)
    // --------------------------------------------------------
    reg [31:0] WriteData_reg;
    always @(*) begin
        if      (Jump || JumpReg) WriteData_reg = PC_Plus4;
        else if (MemtoReg)        WriteData_reg = MemReadData;
        else                      WriteData_reg = ALUResult;
    end
    assign WriteData = WriteData_reg;

    // --------------------------------------------------------
    // MEMORY PORT EXPOSURE (for LED / switch peripherals)
    // --------------------------------------------------------
    assign mem_address    = ALUResult;
    assign mem_write_data = ReadData2;
    assign mem_write_en   = MemWrite;
    assign mem_read_en    = MemRead;
    assign MemReadData    = mem_read_data;

    // --------------------------------------------------------
    // MODULE INSTANTIATIONS
    // --------------------------------------------------------
    ProgramCounter u_pc (
        .clk     (clk),
        .clk_en  (clk_en),
        .rst     (rst),
        .PC_Next (PC_Next),
        .PC      (PC)
    );

    pcAdder u_pcAdder (
        .PC       (PC),
        .PC_Plus4 (PC_Plus4)
    );

    InstructionMemory u_instmem (
        .instAddress (PC),
        .instruction (instruction)
    );

    immGen u_immGen (
        .instruction (instruction),
        .imm_out     (imm_out)
    );

    // BranchTarget = PC + imm  (works for both B-type and J-type)
    branchAdder u_branchAdder (
        .PC           (PC),
        .imm          (imm_out),
        .BranchTarget (BranchTarget)
    );

    MainControl u_main_ctrl (
        .opcode   (opcode),
        .RegWrite (RegWrite),
        .ALUSrc   (ALUSrc),
        .MemRead  (MemRead),
        .MemWrite (MemWrite),
        .MemtoReg (MemtoReg),
        .Branch   (Branch),
        .Jump     (Jump),
        .JumpReg  (JumpReg),
        .ALUOp    (ALUOp)
    );

    ALUControl u_alu_ctrl (
        .ALUOp      (ALUOp),
        .funct3     (funct3),
        .funct7     (funct7),
        .ALUControl (ALUControl)
    );

    RegisterFile u_regfile (
        .clk         (clk),
        .clk_en      (clk_en),
        .rst         (rst),
        .WriteEnable (RegWrite),
        .rs1         (rs1_addr),
        .rs2         (rs2_addr),
        .rd          (rd_addr),
        .WriteData   (WriteData),
        .ReadData1   (ReadData1),
        .ReadData2   (ReadData2)
    );

    mux2 u_mux_alusrc (
        .sel (ALUSrc),
        .in0 (ReadData2),
        .in1 (imm_out),
        .out (ALU_B)
    );

    ALU u_alu (
        .A          (ReadData1),
        .B          (ALU_B),
        .ALUControl (ALUControl),
        .ALUResult  (ALUResult),
        .Zero       (Zero),
        .blt        (blt)
    );

endmodule