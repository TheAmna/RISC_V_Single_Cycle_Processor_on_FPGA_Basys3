`timescale 1ns / 1ps
// ============================================================
// MainControl.v  -  MODIFIED for Part B
// Added: JAL (J-type), JALR (I-type)
// BNE already worked via existing Branch + funct3 logic
// New control signals: Jump, JumpReg
//   Jump    = 1 for JAL  (PC <- PC + imm, rd <- PC+4)
//   JumpReg = 1 for JALR (PC <- rs1 + imm, rd <- PC+4)
// ============================================================

// Instruction types supported:
// R_TYPE  (0110011): ADD SUB SLL SRL AND OR XOR SLT
// I_ARITH (0010011): ADDI ANDI ORI XORI SLLI SRLI
// LOAD    (0000011): LW LH LB
// STORE   (0100011): SW SH SB
// BRANCH  (1100011): BEQ BNE BLT BGE
// JAL     (1101111): Jump and Link           <-- NEW Part B
// JALR    (1100111): Jump and Link Register  <-- NEW Part B
//
// ALUOp encoding:
//   2'b10  R-type
//   2'b11  I-type arithmetic
//   2'b00  Load / Store / JAL / JALR  (ALU does ADD)
//   2'b01  Branch (ALU does SUB for comparison)

module MainControl (
    input  wire [6:0] opcode,
    output reg        RegWrite,
    output reg        ALUSrc,
    output reg        MemRead,
    output reg        MemWrite,
    output reg        MemtoReg,
    output reg        Branch,
    output reg        Jump,        // NEW: 1 for JAL
    output reg        JumpReg,     // NEW: 1 for JALR
    output reg [1:0]  ALUOp
);
    localparam R_TYPE  = 7'b0110011;
    localparam I_ARITH = 7'b0010011;
    localparam LOAD    = 7'b0000011;
    localparam STORE   = 7'b0100011;
    localparam BRANCH  = 7'b1100011;
    localparam JAL     = 7'b1101111;   // NEW
    localparam JALR    = 7'b1100111;   // NEW

    always @(*) begin
        // defaults
        RegWrite = 1'b0; ALUSrc   = 1'b0; MemRead  = 1'b0;
        MemWrite = 1'b0; MemtoReg = 1'b0; Branch   = 1'b0;
        Jump     = 1'b0; JumpReg  = 1'b0; ALUOp    = 2'b00;

        case (opcode)
            R_TYPE: begin
                RegWrite = 1'b1; ALUSrc = 1'b0; ALUOp = 2'b10;
            end
            I_ARITH: begin
                RegWrite = 1'b1; ALUSrc = 1'b1; ALUOp = 2'b11;
            end
            LOAD: begin
                RegWrite = 1'b1; ALUSrc = 1'b1;
                MemRead  = 1'b1; MemtoReg = 1'b1; ALUOp = 2'b00;
            end
            STORE: begin
                ALUSrc = 1'b1; MemWrite = 1'b1; ALUOp = 2'b00;
            end
            BRANCH: begin
                Branch = 1'b1; ALUOp = 2'b01;
            end
            // -------------------------------------------------------
            // JAL: rd = PC+4,  PC = PC + imm  (J-type)
            //   ALU not needed for address - branchAdder reused
            //   RegWrite=1 to save PC+4 into rd
            //   Jump=1 signals TopLevel to use branch target as next PC
            //   and to write PC+4 into rd
            // -------------------------------------------------------
            JAL: begin
                RegWrite = 1'b1;
                Jump     = 1'b1;
                ALUOp    = 2'b00;
            end
            // -------------------------------------------------------
            // JALR: rd = PC+4,  PC = (rs1 + imm) & ~1  (I-type)
            //   ALUSrc=1  -> ALU computes rs1 + imm
            //   JumpReg=1 -> TopLevel uses ALUResult as next PC
            //   RegWrite=1 to save PC+4 into rd
            // -------------------------------------------------------
            JALR: begin
                RegWrite = 1'b1;
                ALUSrc   = 1'b1;
                JumpReg  = 1'b1;
                ALUOp    = 2'b00;   // ALU does ADD (rs1 + imm)
            end
            default: begin
                // all signals already defaulted to 0
            end
        endcase
    end
endmodule